package com.contatos.substituicaoliskov;

/**
 *
 * @author tgp
 */
public class Bonus extends Pagamento {

    public Bonus() {
    }
    
    @Override
    public Pagamento recerberPagamento(Pagamento pag) {
        System.out.printf("Recebeu Pagamento Bonus!");
        return pag;
    }
    
}
