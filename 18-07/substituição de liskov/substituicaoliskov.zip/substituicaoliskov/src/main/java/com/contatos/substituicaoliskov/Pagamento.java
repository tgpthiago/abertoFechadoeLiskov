package com.contatos.substituicaoliskov;

/**
 *
 * @author tgp
 */
public abstract class Pagamento {
    
    public Pagamento recerberPagamento(Pagamento pag) { 
        return pag;
    }
    
}
