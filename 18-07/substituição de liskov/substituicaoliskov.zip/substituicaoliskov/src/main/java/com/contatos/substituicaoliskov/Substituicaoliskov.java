package com.contatos.substituicaoliskov;

/**
 *
 * @author tgp
 */
public class Substituicaoliskov {
    public static void main(String [] args){ 
     Pagamento salario = new Bonus();
     salario.recerberPagamento(salario);
    }
}
