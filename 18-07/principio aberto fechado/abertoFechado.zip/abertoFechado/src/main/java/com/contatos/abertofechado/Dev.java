
package com.contatos.abertofechado;

/**
 *
 * @author tgp
 */
public class Dev implements Funcionario {

    @Override
    public void trabalhar() {
        System.out.printf("Dev foi trabalhar!");
    }
    
}
