
package com.contatos.abertofechado;

/**
 *
 * @author tgp
 */
public class abertoFechado {
    public static void main(String[] args) {
        Funcionario func = new Dev();
        Funcionario func2 = new Faxineiro();
        
       func.trabalhar();
       func2.trabalhar();
    }
}
